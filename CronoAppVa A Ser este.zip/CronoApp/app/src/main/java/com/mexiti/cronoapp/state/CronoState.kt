package com.mexiti.cronoapp.state

data class CronoState(
    //val cronometroActivo: Boolean = false,
    val showSaveButton: Boolean = false,
    val showTextField: Boolean = false,
    val title: String = "",
    val apellido: String="",
    val telefono: Long=0,
)





